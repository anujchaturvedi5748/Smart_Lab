module.exports = {
    // JWT_KEY: ["secret10","secret1","secret2","secret3","secret4","secret5","secret6","secret7","secret8","secret9"]
    JWT_KEY: "secret"
}